This hack is mostly made in educational purposes to people who want to learn how to make AHK , its good hack , but Wares is better
Currently Hacl have 3 functions 2 of which works in both cs go and valorant ( undetected ) ( Auto-Pistol , BunnyHop )
Wallhack works only for cs go it isnt detected by VAC also it wont affect your trust factor, but it will require ANSI-32bit Version of Ahk
if you want more functions added or you found a glitch contact me via discord ( privet#9291 )
